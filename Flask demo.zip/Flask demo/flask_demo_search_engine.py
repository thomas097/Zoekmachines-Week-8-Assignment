from flask import Flask
from flask import request, render_template


app = Flask(__name__)

## TODO Init ES


# HOME
@app.route('/')
def home():
	return render_template('home.html')


# SERP
@app.route('/serp', methods=['POST'])
def search():
	query = request.form["search_bar"]

	# DO STUFF WITH ELASTIC SEARCH
	# return docID, title, artist, year, genre and snippet
	results = [('1', 'God\'s Plan', 'Drake', 'Gods plan... Gods Plan...'),
				('2', 'Rap God', 'Eminem', 'Rap god! Rap bot!'),
				('3', 'No Role Modelz', 'J. Cole', 'No role models and I am here right now!')]
	n_results = len(results)
	
	return render_template('serp.html', n_results=n_results, results=results)


# document page
@app.route('/doc', methods=['POST'])
def open_doc():
	docID = request.form["docID"]
	
	# DO STUFF WITH ELASTIC SEARCH
	# retrieve full data from elastic search using docID to display on page
	results = {'1':('God\'s Plan', 'Drake', 'Gods plan... Gods Plan... But now more!'),
			   '2':('Rap God', 'Eminem', 'Rap god! Rap bot! But now more!'),
			   '3':('No Role Modelz', 'J. Cole', 'No role models and I am here right now! But now more!')}
	result = results[docID]
	
	return render_template('doc.html', result=result)


if __name__ == '__main__':
	app.run()
