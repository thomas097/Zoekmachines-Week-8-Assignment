# Zoekmachines-Week-8-Assignment
This repository contains the Elastic Search asignment for Zoekmachines 2018. The project is described in-depth on the following wiki page:


https://github.com/thomas097/Zoekmachines-Week-8-Assignment/wiki/Zoekmachines-Elastic-Search-Assignment

``` Progress:
Index: Af
Wikipedia linking: Af [echter beetje lage recall van 6% om false positives te verminderen]
Q1: af, simple_search() [als strikte conjunctieve query maar is opzich irrelevant voor demo]
Q2: af, advanced_search() [kleine aanpassing gemaakt met from=0 parameter]
Q3: af
Q4: af
Q5: Heeft een range voor tijd [faceted_test.py heeft een sample met filtering + facet counts]
Q6: ?
Demo: Nathan bezig
```
