from elasticsearch import Elasticsearch, helpers
from wordcloud import WordCloud
from collections import Counter
import numpy as np
import re

import matplotlib

matplotlib.use('Agg')
import matplotlib.pyplot as plt


'''
    Usage:
        1) start elastic search
        2) run function word_cloud()
        3) (optional) call from demo
'''
def grey_color_func(word, font_size, position,orientation,random_state=None, **kwargs):
    return('#008600')

def query_cloud(es, lyrics, random_string, k=40):
    # determine the total number of indexed documents
    N = es.count(index='songs')['count']

    lyrics = ' '.join(lyrics).replace('\n', ' ')
    lyrics = re.sub('[^a-zA-Z0-9 ]', '', lyrics)
    lyric_terms = list(set(lyrics.split(' ')))

    # determine for each term occurring in the returned songs and
    # IDF value (indicating its relevance to the word cloud)
    queries = [{"query": {"term": {"lyrics": t}}, "size":0} for t in lyric_terms]
    res = es.msearch(index='songs', body=queries)
    scores = [(np.log(N/x['hits']['total']), t) for t, x in zip(lyric_terms, res['responses']) if x['hits']['total']]

    # grab top k terms w.r.t. to their IDF value
    top_terms = sorted(scores, key=lambda x: -x[0])[:k]
    top_terms = {x[1]:x[0] for x in top_terms}

    # if there are no lyrics (occurs from time to time) then
    # return default message.
    if not len(top_terms):
        top_terms = {'Not Available':1}

    # create word cloud image using WordCloud library
    wordcloud = WordCloud(background_color='white').generate_from_frequencies(top_terms)
    wordcloud.recolor(color_func = grey_color_func)

    # store image in path
    fig, ax = plt.subplots()
    plt.imshow(wordcloud, interpolation='bilinear')
    plt.axis("off")

    fig.savefig('./static/images/lyrics' + str(random_string) + '.png')


# init elastic search
es = Elasticsearch(hosts=['http://localhost:9200/'])
# word_cloud(es, 'songs', 'born to be alive but this chigga isnt',
#            path='wordcloud.png')

