from elasticsearch import Elasticsearch, helpers
from pprint import pprint
import re

'''
    Usage:
        1) start elastic search
        2) run function advanced_search()
        3) (optional) call from demo
'''


# creates a snippet containing the most amount of words from the query
def create_snippet(lyrics, query, length):
    query_terms = set(query.lower().split(' '))
    lyrics_terms = lyrics.replace('\n', ' ').lower().split(' ')

    # loop over ngrams and return the one with the most query terms
    snippet, score = '', -1
    for i in range(len(lyrics_terms) - length + 1):
        new_snippet = lyrics_terms[i:i + length]
        new_score = len(set(new_snippet).intersection(query_terms))
        if new_score >= score:
            snippet = ' '.join(new_snippet)
            score = new_score
    if len(snippet):
        return snippet
    return lyrics[:length]


# implements simple keyword search in the indexed lyrics
def advanced_search_must(es, index, lyrics, song_title, artist, facets, _from=0, N=10, snip_size=20):
    must_list = []
    if lyrics:
        must_list.append({"match":{"lyrics": lyrics}})
    if song_title:
        must_list.append({"match":{"song_title": song_title}})
    if artist:
        must_list.append({"match":{"artist": {"query":artist, "operator": "and"}}})
    for facet in facets:
        f, v = facet.split(':')
        must_list.append({"match":{f:{"query":v, "operator": "and"}}})

    res = es.search(index=index, body={
        "query": {
            "bool": {
                "must": must_list
            }
        },
        "aggs": {
                "genre": {
                    "terms": {
                        "field": "genre.keyword"
                        }
                    },
                 "year": {
                    "terms": {
                        "field": "year.keyword"
                        }
                    },
                 "artist": {
                    "terms": {
                        "field": "artist.keyword"
                        }
                    },
        },
        "size": N,
        "from": _from})
    
    results_list = []
    for hit in res['hits']['hits']:
        song = hit['_source']
        hit = (hit['_id'], song['song_title'], song['artist'], song['genre'], song['year'],
               create_snippet(song['lyrics'], lyrics, snip_size), song["lyrics"])
        results_list.append(hit)

    facets = dict()
    for facet, count in res['aggregations'].items():
        facets[facet] = [(c['key'], c['doc_count']) for c in count['buckets']][:3]
    
    # results_list, and res to use for timeline
    return results_list, res, facets
